module pe.edu.upeu.sysventas {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires static lombok;
    requires jakarta.validation;

    opens pe.edu.upeu.sysventas to javafx.fxml;
    opens pe.edu.upeu.sysventas.controller to javafx.fxml;
    exports pe.edu.upeu.sysventas;
    opens pe.edu.upeu.sysventas.model;

    opens pe.edu.upeu.sysventas.cine to javafx.fxml, javafx.base;
    exports pe.edu.upeu.sysventas.cinerun;
    exports pe.edu.upeu.sysventas.cinebasic;

}